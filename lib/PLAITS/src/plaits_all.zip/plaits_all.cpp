// braids_all.cpp - Single compilation unit for BRAIDS
// Only includes the .cc files that exist in poetaster's arduinoMI port

#include <STMLIB.h>

#include "plaits/resources.cc"


#include "plaits/dsp/voice.cc"
#include "plaits/dsp/speech/lpc_speech_synth.cc"
#include "plaits/dsp/speech/lpc_speech_synth_controller.cc"
#include "plaits/dsp/speech/lpc_speech_synth_phonemes.cc"
#include "plaits/dsp/speech/lpc_speech_synth_words.cc"
#include "plaits/dsp/speech/naive_speech_synth.cc"
#include "plaits/dsp/speech/sam_speech_synth.cc"
#include "plaits/dsp/engine/additive_engine.cc"
#include "plaits/dsp/engine/bass_drum_engine.cc"
#include "plaits/dsp/engine/chord_engine.cc"
#include "plaits/dsp/engine/fm_engine.cc"
#include "plaits/dsp/engine/grain_engine.cc"
#include "plaits/dsp/engine/hi_hat_engine.cc"
#include "plaits/dsp/engine/modal_engine.cc"
#include "plaits/dsp/engine/noise_engine.cc"
#include "plaits/dsp/engine/particle_engine.cc"
#include "plaits/dsp/engine/snare_drum_engine.cc"
#include "plaits/dsp/engine/speech_engine.cc"
#include "plaits/dsp/engine/string_engine.cc"
#include "plaits/dsp/engine/swarm_engine.cc"
#include "plaits/dsp/engine/virtual_analog_engine.cc"
#include "plaits/dsp/engine/waveshaping_engine.cc"
#include "plaits/dsp/engine/wavetable_engine.cc"
#include "plaits/dsp/physical_modelling/modal_voice.cc"
#include "plaits/dsp/physical_modelling/resonator.cc"
#include "plaits/dsp/physical_modelling/string.cc"
#include "plaits/dsp/physical_modelling/string_voice.cc"

#include "plaits/dsp/chords/chord_bank.cc"
#include "plaits/dsp/fm/algorithms.cc"
#include "plaits/dsp/fm/dx_units.cc"


#include "plaits/dsp/engine2/wave_terrain_engine.cc"
#include "plaits/dsp/engine2/virtual_analog_vcf_engine.cc"
#include "plaits/dsp/engine2/phase_distortion_engine.cc"
#include "plaits/dsp/engine2/six_op_engine.cc"

