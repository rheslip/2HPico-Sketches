
// Fabyrinth sequencer - similar to Moog Labyrinth
// RH for new 2HP hardware Dec 2025
// module must be jumpered for CV out on jack 2 which is used as Gate output

//#include "MIDI.h"
#include "io.h"
#include <I2S.h>
#include <Adafruit_NeoPixel.h>
//#include "RPi_Pico_TimerInterrupt.h"
#include <math.h>
#include "scales.h"

#include "pico/multicore.h"

#ifndef _BV
#define _BV(bit) (1 << (bit)) 
#endif

#define MONITOR_CPU1  // define to enable 2nd core monitoring

//#define SAMPLERATE 11025 
#define SAMPLERATE 22050  // saves CPU cycles
//#define SAMPLERATE 44100

#define NUMPIXELS 1 // 
#define RED 0x1f0000  // only using 5 bits to keep LEDs from getting too bright
#define GREEN 0x001f00
#define BLUE 0x00001f
#define ORANGE (RED|GREEN)
#define VIOLET (RED|BLUE)
#define AQUA (GREEN|BLUE)

Adafruit_NeoPixel LEDS(NUMPIXELS, LEDPIN, NEO_GRB + NEO_KHZ800);

I2S DAC(OUTPUT);  // 

#define DEBUG   // comment out to remove debug code

// constants for integer to float and float to integer conversion
#define MULT_16 2147483647
#define DIV_16 4.6566129e-10

// sequencer stuff
#define MAX_STEPS 16
#define NOTERANGE 36  // 3 octave range seems reasonable
#define CLOCKIN TRIGGER  // top jack is clock
#define GATEHIGH -32767    // DAC values for gate levels
#define GATELOW 32767



// a/d values from pots
// pots are used for two or more parameters so we don't change the values till
// there is a significant movement of the pots when the pots are "locked"
// this prevents a waveform or level change ("shift" parameters) from changing the ramp times when the shift button is released

#define AD_BITS 12
#define AD_RANGE 4096
#define POT1  AIN1  // lowest pot GPIO # 

#define MIN_POT_CHANGE 100 // pot reading must change by this in order to register
#define POT_AVERAGING 5  // A/D average over this many readings
#define NUMPOTS 3
uint16_t pot[NUMPOTS]; // pot A/D readings
bool potlock[NUMPOTS]; // when pots are locked it means they must change by MIN_POT_CHANGE to register

#define CVIN_VOLT 580.6  // a/d count per volt - trim for V/octave
#define CVIN AIN0   // CV input
#define CV_AVERAGING 10  // A/D average over this many readings
#define CVOUT_VOLT 6554 // D/A count per volt - nominally +-5v range for -+32767 DAC values- trim for V/octave out
#define CVOUTMIN -2*CVOUT_VOLT  // lowest output CV ie MIDI note 0

int8_t notes[MAX_STEPS]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
bool gates[MAX_STEPS]={1,1,1,0,1,0,0,0,1,0,0,0,1,0,0,0};
int16_t gateout=GATELOW;      // sent to right dac channel
int16_t cvout=CVOUTMIN;  // sent to left DAC channel
int16_t cvoffset=12000; // set by UI
int8_t stepindex=0;
int8_t laststep=15;
int8_t noterange=7;
int16_t scale=0;
int8_t noteprob=10;      // probability of changing notes 0-99
int8_t gateprob=10;      // "" gates
int8_t clockdivideby=1;  // divide input clock by this
int8_t clockdivider=1;   // counts down clocks

bool clocked=0;  // keeps track of clock state
bool button=0;  // keeps track of button state

#define NUMUISTATES 2
enum UIstates {SET1,SET2} ;
uint8_t UIstate=SET1;
uint32_t buttontimer,clocktimer,clockperiod,clockdebouncetimer,ledtimer, gatetimer, gatelength;

#define DEBOUNCE 10
#define CLOCK_DEBOUNCE 1  // 
#define LEDOFF 100 // LED trigger flash time 

// sample the pots. potlock means apply hysteresis so we only change when the pot is moved significantly
void samplepots(void) {
  for (int i=0; i<NUMPOTS;++i) {
    uint val=0;
    for (int j=0; j<POT_AVERAGING;++j) val+=analogRead(POT1+i); // read the A/D a few times and average for a more stable value
    val=val/POT_AVERAGING;
    if (potlock[i]) {
      int delta=pot[i]-val;  // this needs to be done outside of the abs() function - see arduino abs() docs
      if (abs(delta) > MIN_POT_CHANGE) {
        potlock[i]=0;   // flag pot no longer locked
        pot[i]=val; // save the new reading
      }
    }
    else pot[i]=val; // pot is unlocked so save the reading
  }
}

// lock all pots. when locked they have to move significantly to change value. 
// prevents immediately setting new values when parameter set is changed with front panel button
void lockpots(void) {
  for (int i=0; i<NUMPOTS;++i) potlock[i]=1;
}

// sample the CV input. potlock means apply hysteresis so we only change when the pot is moved significantly
uint16_t sampleCV(void) {
  uint16_t val=0;
  for (int16_t j=0; j<CV_AVERAGING;++j) val+=analogRead(CVIN); // read the A/D a few times and average for a more stable value
  val=val/CV_AVERAGING;
  return val;
}

// like the map() function but maps to float values
float mapf(long x, long in_min, long in_max, float out_min, float out_max) {
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

// requantizes note array to current scale setting
void requantizenotes(void) {
  for (int16_t i=0; i< MAX_STEPS;++i) notes[i]=quantize(notes[i],scales[scale],0);
}

void setup() { 
  Serial.begin(115200);

#ifdef DEBUG

  Serial.println("starting setup");  
#endif

// set up I/O pins
 
#ifdef MONITOR_CPU1 // for monitoring 2nd core CPU usage
  pinMode(CPU_USE,OUTPUT); // hi = CPU busy
#endif 

  pinMode(TRIGGER,INPUT_PULLUP); // gate/trigger in
  pinMode(BUTTON1,INPUT_PULLUP); // button in

  LEDS.begin(); // INITIALIZE NeoPixel strip object (REQUIRED)
  LEDS.setPixelColor(0, RED); 
  LEDS.show();

  analogReadResolution(AD_BITS); // set up for max resolution
// initialize the pot readings
  for (int16_t i=0; i<NUMPOTS;++i) {
    pot[i]=0;
    potlock[i]=0;
  }


  // Enable the AudioShield
// set up Pico I2S for PT8211 stereo DAC
	DAC.setBCLK(BCLK);
	DAC.setDATA(I2S_DATA);
	DAC.setBitsPerSample(16);
	DAC.setBuffers(1, 128, 0); // DMA buffer - 32 bit L/R words
	DAC.setLSBJFormat();  // needed for PT8211 which has funny timing
	DAC.begin(SAMPLERATE);

#ifdef DEBUG  
  Serial.println("finished setup");  
#endif
  clocktimer=millis(); // initial clock measurement
}



void loop() {

  if (!digitalRead(BUTTON1)) {
    if (((millis()-buttontimer) > DEBOUNCE) && !button) {  // if button pressed advance to next parameter set
      button=1;  
      ++UIstate;
      if (UIstate >= NUMUISTATES) UIstate=SET1;
      lockpots();
  //    Serial.printf("state %d %d\n",UIstate, sizeof(UIstates)); 
    }
  }
  else {
    buttontimer=millis();
    button=0;
  }

  samplepots();

// set parameters from panel pots
// 
  switch (UIstate) {
    case SET1:
      LEDS.setPixelColor(0, RED); 
      if (!potlock[2]) noteprob=map(pot[2],0,AD_RANGE-1,0,100); // top pot on the panel
      if (!potlock[1]) gateprob=map(pot[1],0,AD_RANGE-1,0,100);  // 
      if (!potlock[0]) cvoffset=map(pot[0],0,AD_RANGE-1,CVOUTMIN,32767); 
      break;
    case SET2:
      LEDS.setPixelColor(0, GREEN);
      //if (!potlock[2]) laststep=map(pot[2],0,AD_RANGE-1,0,15); // top pot on the panel 
      if (!potlock[1]) {
        scale=map(pot[1],0,AD_RANGE,0,4);  // too many scales gets hard to discern by ear 
        requantizenotes();
      }
                                                            // *** should also requantize the sequence here when scale changes to purge out of scale notes
      // if (!potlock[0]) clockdivideby=map(pot[0],0,AD_RANGE-1,1,16); // clock dvider works but should probably be limited to /2/4/8 ?
      if (!potlock[0]) noterange=map(pot[0],0,AD_RANGE-1,0,NOTERANGE);
      break;
    default:
      break;
  }

  if (!digitalRead(CLOCKIN)) {  // look for rising edge of clock input which is inverted
    if (((millis()-clockdebouncetimer) > CLOCK_DEBOUNCE) && !clocked) {  // true if we have a debounced clock rising edge
      --clockdivider;
      clocked=1;
      if (clockdivider <=0) {       
        clockdivider=clockdivideby;
        clockperiod=millis()-clocktimer; // measure clock so we can set gate time relative to clock period
        clocktimer=millis();

        ++stepindex; // advance sequencer
        if (stepindex > laststep) stepindex=0;
        int p=random(100);
        if (p < noteprob) notes[stepindex]=quantize(random(noterange),scales[scale],0);  //root is always MIDI note 0 - CV offset actually sets output pitch 
        if (p < gateprob) gates[stepindex]=(bool)random(2);
        if (gates[stepindex]) {
          cvout=-(notes[stepindex]*(CVOUT_VOLT/12)+CVOUTMIN+cvoffset); // 1v per octave. note numbers are MIDI style 0-128. DAC out is inverted. change CV only if there is a gate
          gateout=GATEHIGH;
          gatelength=clockperiod/2; // *** this will be adjustable
          gatetimer=millis(); // start gate timer
          LEDS.setPixelColor(0,0 ); // show gate as a LED off flash
          LEDS.show();  // update LED
          ledtimer=millis(); // start led off timer
 //         Serial.printf("scale %s note %s \n",scalenames[scale],notenames[notes[stepindex]%12]);
        }
        else gateout=GATELOW;
      }
    }
  }
  else {   
      clocked=0;
      clockdebouncetimer=millis();
  }

  if ((millis()-gatetimer) > gatelength) gateout=GATELOW;  // turn off gate after gate length

  if ((millis()-ledtimer) > LEDOFF ) LEDS.show();  // update LEDs only if not doing off flash
}

// second core setup
// second core is dedicated to sample processing
void setup1() {
delay (1000); // wait for main core to start up peripherals
}

// process audio samples
void loop1(){

#ifdef MONITOR_CPU1  
  digitalWrite(CPU_USE,0); // low - CPU not busy
#endif
 // write samples to DMA buffer - this is a blocking call so it stalls when buffer is full
	DAC.write(int16_t(cvout)); // left
	DAC.write(int16_t(gateout)); // right

#ifdef MONITOR_CPU1
  digitalWrite(CPU_USE,1); // hi = CPU busy
#endif
}





