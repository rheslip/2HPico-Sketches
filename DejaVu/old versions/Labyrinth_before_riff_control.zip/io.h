
// Copyright 2023 Rich Heslip
//
// Author: Rich Heslip 
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
// 
// See http://creativecommons.org/licenses/MIT/ for more information.
//
// -----------------------------------------------------------------------------
//
// I/O pin definitions for Raspberry Pi Pico eurorack module


#ifndef IO_H_
#define IO_H_


// I2S pins for DAC
#define BCLK 13
#define WS 14  // this will always be 1 pin above BCLK - can't change it
#define I2S_DATA 15

#define CPU_USE 8

// Gate/trigger/clock digital inputs 
#define TRIGGER 0

#define BUTTON1 2
#define LEDPIN 3 // for RGB Led

#define AIN0 	26
#define AIN1 	27
#define AIN2 	28
#define AIN3 	29 // not available on standard Pico board

/*
#define SPI0_MOSI 19
#define SPI0_MISO 16
#define SPI0_CS 17
#define SPI0_SCLK 18


// OLED display pins
#define OLED_DC     2
#define OLED_CS     17
#define OLED_RESET  3

#define ENC_A 11  // encoder
#define ENC_B 12
#define ENC_SW   10 


#define BUTTON1 4
#define BUTTON2 5
#define BUTTON3 6
#define BUTTON4 7
#define BUTTON5 26
#define BUTTON6 22
#define BUTTON7 21

// analog inputs for voltage control - range approx 0-5v
// 
#define AIN0 	26
#define AIN1 	27
#define AIN2 	28
#define AIN3 	29 // not available on standard Pico board

// battery monitor
#define BAT_VOLTAGE AIN1

// Gate/trigger digital inputs 
#define GATE0 4
#define GATE1	5
#define GATE2	6
#define GATE3	7

#define IRQ_PIN 20 // MPR121 IRQ

// MIDI serial port pins - not really MIDI but the serial port is exposed on the first two jacks
#define MIDIRX 1
#define MIDITX 0
*/
#endif // IO_H_

